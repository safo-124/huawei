"""ADM submission model: Rest / Activity / Stress from wrist signals.

This module is the single source of truth for preprocessing and features.
Training code imports it, so training and inference cannot diverge.

Allowed imports in the evaluation environment: numpy, pandas, pyarrow, scipy,
scikit-learn, onnxruntime (plus the standard library).

Pipeline inside run():
  1. Extract each signal at its native rate, apply range checks.
  2. Aggregate every signal onto a 1 Hz grid anchored at the first input
     timestamp (by time, never by row count), keeping per-second counts so
     gaps stay visible.
  3. Window features (10 s, 60 s, 180 s, centred) computed with cumulative sums.
  4. ONNX classifier gives per-second class probabilities.
  5. Optional per-class log offsets and HMM smoothing (configured through the
     ONNX metadata, so the .py never changes between variants).
  6. Per-second decisions are mapped back onto every input row.
"""

import json
import pathlib

import numpy as np
import pandas as pd
import onnxruntime as ort

try:
    from adm_base_class import ADM_Base
except ImportError:  # local fallback with the identical interface
    import abc

    class ADM_Base(abc.ABC):
        def load_model(self, onnx_file: pathlib.Path) -> None:
            self.session = ort.InferenceSession(
                onnx_file, providers=["CPUExecutionProvider"]
            )

        @abc.abstractmethod
        def run(self, input: pd.DataFrame) -> pd.DataFrame:
            pass


CLASSES = ("Rest", "Activity", "Stress")
WINDOWS = (10, 60, 180)
NS = 1_000_000_000

# Physiological range checks; values outside are treated as missing.
HR_RANGE = (30.0, 220.0)
IBI_RANGE = (0.25, 2.0)
TEMP_RANGE = (20.0, 42.0)
MISS_TOL = 0.05  # IBI_dt - IBI_duration above this means at least one missed beat


# --------------------------------------------------------------------------
# Labels (official mapping from phases_to_activity.txt)
# --------------------------------------------------------------------------
STRESS_PHASES = {"Stroop", "TMCT", "Real opinion", "Opposite opinion", "Subtraction"}
ACTIVITY_PHASES = {"Warm-up", "Sprint", "Cooldown"}
REST_PHASES = {"Baseline", "Rest"}


def phase_to_label(phase):
    """Map a protocol phase to Rest/Activity/Stress, or None when not scored."""
    if not isinstance(phase, str):
        return None
    p = phase.strip()
    if p in STRESS_PHASES:
        return "Stress"
    if p in ACTIVITY_PHASES or "rpm" in p:
        return "Activity"
    if p in REST_PHASES:
        return "Rest"
    return None


# --------------------------------------------------------------------------
# Per-second aggregation
# --------------------------------------------------------------------------
def _col(df, name):
    if name in df.columns:
        return df[name].to_numpy(dtype=np.float64, na_value=np.nan)
    return np.full(len(df), np.nan)


def seconds_index(index):
    """Integer second of each row relative to the first timestamp."""
    t = index.values.astype("datetime64[ns]").astype(np.int64)
    return (t - t[0]) // NS, t


def per_second(df):
    """Aggregate raw signals to 1 Hz sums and counts. Returns (sec, n, base dict)."""
    sec, t_ns = seconds_index(df.index)
    n = int(sec[-1]) + 1
    b = {}

    def bc(s, w=None):
        return np.bincount(s, weights=w, minlength=n).astype(np.float64)

    # HR (1 Hz)
    hr = _col(df, "HR")
    m = (hr >= HR_RANGE[0]) & (hr <= HR_RANGE[1])
    s = sec[m]
    b["hr_c"] = bc(s)
    b["hr_s"] = bc(s, hr[m])
    b["hr_q"] = bc(s, hr[m] ** 2)

    # EDA (4 Hz)
    eda = _col(df, "EDA")
    m = eda >= 0
    s, v = sec[m], eda[m]
    b["eda_c"] = bc(s)
    b["eda_s"] = bc(s, v)
    b["eda_q"] = bc(s, v * v)
    if len(v) > 1:
        dv = np.diff(v)
        dt = np.diff(t_ns[m]) / NS
        ok = dt < 0.5  # only consecutive 4 Hz samples
        rise = np.where(ok & (dv > 0), dv, 0.0)
        b["eda_rise"] = bc(s[1:], rise)
    else:
        b["eda_rise"] = np.zeros(n)

    # Temperature (4 Hz)
    tmp = _col(df, "Temperature")
    m = (tmp >= TEMP_RANGE[0]) & (tmp <= TEMP_RANGE[1])
    s = sec[m]
    b["tmp_c"] = bc(s)
    b["tmp_s"] = bc(s, tmp[m])

    # BVP (64 Hz)
    bvp = _col(df, "BVP")
    m = np.isfinite(bvp)
    s, v = sec[m], bvp[m]
    b["bvp_c"] = bc(s)
    b["bvp_s"] = bc(s, v)
    b["bvp_q"] = bc(s, v * v)
    rng = np.full(n, np.nan)
    if len(v) > 1:
        dv = np.abs(np.diff(v))
        ok = (np.diff(t_ns[m]) <= NS // 32)
        b["bvp_d"] = bc(s[1:], np.where(ok, dv, 0.0))
        b["bvp_dc"] = bc(s[1:], ok.astype(np.float64))
        starts = np.flatnonzero(np.r_[True, s[1:] != s[:-1]])
        rng[s[starts]] = np.maximum.reduceat(v, starts) - np.minimum.reduceat(v, starts)
    else:
        b["bvp_d"] = np.zeros(n)
        b["bvp_dc"] = np.zeros(n)
    b["bvp_rng"] = rng

    # IBI beats
    dur = _col(df, "IBI_duration")
    idt = _col(df, "IBI_dt")
    m = (dur >= IBI_RANGE[0]) & (dur <= IBI_RANGE[1])
    s, d = sec[m], dur[m]
    gap = np.clip(np.nan_to_num(idt[m] - d, nan=0.0), 0.0, 10.0)
    missed = gap > MISS_TOL
    b["ibi_c"] = bc(s)
    b["ibi_s"] = bc(s, d)
    b["ibi_q"] = bc(s, d * d)
    b["ibi_miss"] = bc(s, missed.astype(np.float64))
    b["ibi_gap"] = bc(s, gap)
    if len(d) > 1:
        dd = np.diff(d)
        ok = ~missed[1:]  # successive difference only between adjacent beats
        b["ibi_dd"] = bc(s[1:], np.where(ok, dd * dd, 0.0))
        b["ibi_ddc"] = bc(s[1:], ok.astype(np.float64))
    else:
        b["ibi_dd"] = np.zeros(n)
        b["ibi_ddc"] = np.zeros(n)
    return sec, n, b


# --------------------------------------------------------------------------
# Window helpers (centred windows via cumulative sums)
# --------------------------------------------------------------------------
def _wsum(x, w):
    """Centred moving sum of x (NaN treated as 0) over w seconds."""
    n = len(x)
    c = np.concatenate(([0.0], np.cumsum(np.nan_to_num(x))))
    h = w // 2
    i = np.arange(n)
    lo = np.clip(i - h, 0, n)
    hi = np.clip(i - h + w, 0, n)
    return c[hi] - c[lo]


def _ratio(a, b, min_b=1e-9):
    with np.errstate(invalid="ignore", divide="ignore"):
        return np.where(b > min_b, a / np.where(b > min_b, b, 1.0), np.nan)


def _wmean(s, c, w):
    return _ratio(_wsum(s, w), _wsum(c, w))


def _wstd(s, q, c, w):
    cs = _wsum(c, w)
    mu = _ratio(_wsum(s, w), cs)
    var = _ratio(_wsum(q, w), cs) - mu * mu
    return np.sqrt(np.maximum(var, 0.0))


def _wslope(y, w):
    """Least squares slope (units per second) of a 1 Hz series with NaNs."""
    n = len(y)
    m = np.isfinite(y).astype(np.float64)
    t = np.arange(n, dtype=np.float64) - n / 2.0
    yy = np.where(m > 0, y, 0.0)
    sn = _wsum(m, w)
    st = _wsum(t * m, w)
    sy = _wsum(yy, w)
    stt = _wsum(t * t * m, w)
    sty = _wsum(t * yy, w)
    den = sn * stt - st * st
    return _ratio(sn * sty - st * sy, den * (sn >= max(3, w // 4)), 1e-9)


def _lag(x, k):
    out = np.full_like(x, np.nan)
    if k < len(x):
        out[k:] = x[k:] - x[:-k]
    return out


# --------------------------------------------------------------------------
# Feature sets
# --------------------------------------------------------------------------
def features_raw(b, n):
    """Variant B: raw window features. Returns (names, matrix n x F)."""
    f = {}
    hr1 = _ratio(b["hr_s"], b["hr_c"])
    rng = b["bvp_rng"]
    rng_c = np.isfinite(rng).astype(np.float64)
    rng0 = np.nan_to_num(rng)
    for w in WINDOWS:
        f[f"hr_mean_{w}"] = _wmean(b["hr_s"], b["hr_c"], w)
        f[f"hr_std_{w}"] = _wstd(b["hr_s"], b["hr_q"], b["hr_c"], w)
        f[f"ibi_mean_{w}"] = _wmean(b["ibi_s"], b["ibi_c"], w)
        f[f"ibi_sdnn_{w}"] = _wstd(b["ibi_s"], b["ibi_q"], b["ibi_c"], w)
        f[f"ibi_rmssd_{w}"] = np.sqrt(_wmean(b["ibi_dd"], b["ibi_ddc"], w))
        cnt = _wsum(b["ibi_c"], w)
        f[f"beat_rate_{w}"] = cnt / w
        f[f"miss_rate_{w}"] = _ratio(_wsum(b["ibi_miss"], w), cnt)
        f[f"gap_mean_{w}"] = _ratio(_wsum(b["ibi_gap"], w), cnt)
        f[f"eda_mean_{w}"] = _wmean(b["eda_s"], b["eda_c"], w)
        f[f"eda_std_{w}"] = _wstd(b["eda_s"], b["eda_q"], b["eda_c"], w)
        f[f"eda_rise_{w}"] = _wmean(b["eda_rise"], (b["eda_c"] > 0).astype(float), w)
        f[f"tmp_mean_{w}"] = _wmean(b["tmp_s"], b["tmp_c"], w)
        f[f"bvp_std_{w}"] = _wstd(b["bvp_s"], b["bvp_q"], b["bvp_c"], w)
        f[f"bvp_hf_{w}"] = _wmean(b["bvp_d"], b["bvp_dc"], w)
        f[f"bvp_amp_{w}"] = _wmean(rng0, rng_c, w)
        f[f"bvp_amp_std_{w}"] = _wstd(rng0, rng0 * rng0, rng_c, w)
    eda1 = _ratio(b["eda_s"], b["eda_c"])
    tmp1 = _ratio(b["tmp_s"], b["tmp_c"])
    for w in (60, 180):
        f[f"hr_slope_{w}"] = _wslope(hr1, w)
        f[f"eda_slope_{w}"] = _wslope(eda1, w)
        f[f"tmp_slope_{w}"] = _wslope(tmp1, w)
    for key in ("hr_mean_60", "eda_mean_60", "tmp_mean_60", "bvp_std_60"):
        for k in (60, 180):
            f[f"{key}_d{k}"] = _lag(f[key], k)
    names = list(f)
    X = np.empty((n, len(names)), dtype=np.float32)
    for j, k in enumerate(names):
        X[:, j] = f[k]
    return names, X


FEATURE_SETS = {"B": features_raw}


def step_points(n, step):
    """Seconds at which to evaluate the classifier and the map back to all seconds.

    The classifier runs every `step` seconds (at the centre of each block) and
    each second takes the prediction of its block. Scoring uses 10 s windows,
    so a step of a few seconds costs little accuracy and saves inference time.
    """
    if step <= 1:
        i = np.arange(n)
        return i, i
    pts = np.minimum(np.arange(step // 2, n + step - 1, step), n - 1)
    pts = pts[: (n + step - 1) // step]
    back = np.minimum(np.arange(n) // step, len(pts) - 1)
    return pts, back


def compute_features(df, variant="B"):
    """Returns (sec, names, X): row-to-second map and per-second feature matrix."""
    sec, n, b = per_second(df)
    names, X = FEATURE_SETS[variant](b, n)
    return sec, names, X


# --------------------------------------------------------------------------
# Decoding: offsets and HMM
# --------------------------------------------------------------------------
def viterbi(logp, log_trans, log_start):
    """Viterbi path for per-step log emissions (T x K)."""
    T, K = logp.shape
    back = np.empty((T, K), dtype=np.int8)
    d = log_start + logp[0]
    for t in range(1, T):
        sc = d[:, None] + log_trans
        back[t] = np.argmax(sc, axis=0)
        d = sc[back[t], np.arange(K)] + logp[t]
    path = np.empty(T, dtype=np.int64)
    path[-1] = int(np.argmax(d))
    for t in range(T - 1, 0, -1):
        path[t - 1] = back[t, path[t]]
    return path


def decode(proba, cfg):
    """Turn per-second probabilities into class codes using cfg."""
    logp = np.log(np.clip(proba, 1e-6, 1.0))
    if "priors" in cfg:
        logp = logp - np.log(np.asarray(cfg["priors"]))
    if "offsets" in cfg:
        logp = logp + np.asarray(cfg["offsets"])
    if "log_trans" in cfg:
        lt = np.asarray(cfg["log_trans"])
        step = int(cfg.get("hmm_step", 1))
        if step > 1:
            path = viterbi(logp[::step], lt, np.full(3, -np.log(3)))
            return np.repeat(path, step)[: len(logp)]
        return viterbi(logp, lt, np.full(3, -np.log(3)))
    return np.argmax(logp, axis=1)


# --------------------------------------------------------------------------
# Model
# --------------------------------------------------------------------------
class ADMModel(ADM_Base):
    def load_model(self, onnx_file: pathlib.Path) -> None:
        so = ort.SessionOptions()
        so.intra_op_num_threads = 1
        so.inter_op_num_threads = 1
        self.session = ort.InferenceSession(
            str(onnx_file), sess_options=so, providers=["CPUExecutionProvider"]
        )
        meta = self.session.get_modelmeta().custom_metadata_map
        self.cfg = json.loads(meta.get("adm_config", "{}"))
        self.variant = self.cfg.get("variant", "B")
        self.input_name = self.session.get_inputs()[0].name
        outs = [o.name for o in self.session.get_outputs()]
        self.prob_name = "probabilities" if "probabilities" in outs else outs[-1]
        self.labels = np.array(CLASSES, dtype=object)

    def predict_seconds(self, input: pd.DataFrame):
        """Returns (sec, per-second class probabilities)."""
        sec, _, X = compute_features(input, self.variant)
        step = int(self.cfg.get("pred_step", 1))
        pts, back = step_points(X.shape[0], step)
        Xs = np.ascontiguousarray(X[pts])
        proba = self.session.run([self.prob_name], {self.input_name: Xs})[0][back]
        return sec, proba

    def run(self, input: pd.DataFrame) -> pd.DataFrame:
        if len(input) == 0:
            return pd.DataFrame({"Activity": pd.Series([], dtype=object)}, index=input.index)
        sec, proba = self.predict_seconds(input)
        codes = decode(proba, self.cfg)
        out = pd.Series(self.labels[codes[sec]], index=input.index, dtype=object)
        return pd.DataFrame({"Activity": out})


def get_model():
    model = ADMModel()
    model.load_model(pathlib.Path(__file__).with_suffix(".onnx"))
    return model
